@extends('layouts.admin')
@section('title', 'E-Paper Editions')

@section('content')
<div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
    <div class="lg:col-span-8 space-y-4">
        <div>
            <h1 class="text-xl font-semibold text-zinc-900 dark:text-zinc-50 tracking-tight">E-Paper Editions</h1>
            <p class="text-xs text-zinc-500 mt-0.5">Manage digital print-replica broadsheet issues.</p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            @forelse($editions as $edition)
                <div class="rounded-2xl border border-zinc-200/70 dark:border-zinc-800/80 bg-white dark:bg-zinc-900/50 overflow-hidden">
                    <div class="aspect-[16/9] bg-zinc-100 dark:bg-zinc-800">
                        <img src="{{ $edition->cover_image }}" alt="{{ $edition->title }}" class="h-full w-full object-cover">
                    </div>
                    <div class="p-4 space-y-2">
                        <div class="flex items-center justify-between text-[11px] text-zinc-400">
                            <span>{{ $edition->edition_date?->format('M d, Y') }}</span>
                            <span>{{ $edition->total_pages }} pages</span>
                        </div>
                        <h3 class="text-sm font-medium text-zinc-900 dark:text-zinc-100">{{ $edition->title }}</h3>
                        <div class="pt-2 flex items-center justify-between">
                            <form method="POST" action="{{ route('admin.epapers.toggle', $edition) }}">
                                @csrf @method('PATCH')
                                <button type="submit" class="px-2.5 py-0.5 rounded-full text-[11px] font-medium cursor-pointer {{ $edition->status === 'published' ? 'bg-emerald-50 text-emerald-700' : 'bg-zinc-100 text-zinc-600' }}">
                                    {{ ucfirst($edition->status) }}
                                </button>
                            </form>
                            <form method="POST" action="{{ route('admin.epapers.destroy', $edition) }}" onsubmit="return confirmDelete(event, 'Delete E-Paper edition &quot;{{ addslashes($edition->title) }}&quot;?')">
                                @csrf @method('DELETE')
                                <button type="submit" class="text-xs text-zinc-400 hover:text-red-600 cursor-pointer">Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
            @empty
                <div class="col-span-full p-8 text-center text-xs text-zinc-400">No E-Paper editions created yet.</div>
            @endforelse
        </div>
    </div>

    <div class="lg:col-span-4">
        <form method="POST" action="{{ route('admin.epapers.store') }}"
              class="rounded-2xl border border-zinc-200/70 dark:border-zinc-800/80 bg-white dark:bg-zinc-900/50 p-5 space-y-4">
            @csrf
            <h2 class="text-sm font-semibold text-zinc-900 dark:text-zinc-100">Publish New Edition</h2>
            <div>
                <label class="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1">Edition Title *</label>
                <input type="text" name="title" required placeholder="Morning Broadsheet Edition" class="w-full rounded-xl border border-zinc-200 dark:border-zinc-800 bg-transparent px-3 py-2 text-xs">
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1">Date</label>
                    <input type="date" name="edition_date" value="{{ now()->toDateString() }}" required class="w-full rounded-xl border border-zinc-200 dark:border-zinc-800 bg-transparent px-3 py-2 text-xs">
                </div>
                <div>
                    <label class="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1">Pages</label>
                    <input type="number" name="total_pages" value="16" min="1" max="64" class="w-full rounded-xl border border-zinc-200 dark:border-zinc-800 bg-transparent px-3 py-2 text-xs">
                </div>
            </div>
            <div>
                <label class="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1">Status</label>
                <select name="status" class="w-full rounded-xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 px-3 py-2 text-xs">
                    <option value="published">Published</option>
                    <option value="draft">Draft</option>
                </select>
            </div>
            <button type="submit" class="w-full py-2 rounded-xl bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 text-xs font-medium cursor-pointer">
                Create Edition
            </button>
        </form>
    </div>
</div>
@endsection

