@extends('layouts.admin')
@section('title', 'Comments Moderation')

@section('content')
<div class="space-y-6">
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
            <h1 class="text-xl font-semibold text-zinc-900 dark:text-zinc-50 tracking-tight">Reader Comments</h1>
            <p class="text-xs text-zinc-500 mt-0.5">Moderate community responses before or after publication.</p>
        </div>

        <div class="flex items-center gap-1.5 text-xs">
            @foreach(['all' => 'All', 'pending' => 'Pending', 'approved' => 'Approved', 'spam' => 'Spam'] as $key => $label)
                <a href="{{ route('admin.comments.index', ['status' => $key]) }}"
                   class="px-3 py-1 rounded-full {{ request('status', 'all') === $key ? 'bg-zinc-900 text-white dark:bg-white dark:text-zinc-900 font-medium' : 'text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800' }}">
                    {{ $label }}
                </a>
            @endforeach
        </div>
    </div>

    <div class="rounded-2xl border border-zinc-200/70 dark:border-zinc-800/80 bg-white dark:bg-zinc-900/50 divide-y divide-zinc-100 dark:divide-zinc-800/60">
        @forelse($comments as $comment)
            <div class="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div class="space-y-1 flex-1">
                    <div class="flex items-center gap-2 text-xs">
                        <span class="font-medium text-zinc-900 dark:text-zinc-100">{{ $comment->author_name }}</span>
                        <span class="text-zinc-400">on</span>
                        <span class="text-zinc-700 dark:text-zinc-300 font-medium truncate max-w-xs">{{ $comment->article?->title ?? 'Article' }}</span>
                        <span class="text-[11px] font-medium
                            {{ $comment->status === 'approved' ? 'text-emerald-600 dark:text-emerald-400' : ($comment->status === 'pending' ? 'text-amber-600 dark:text-amber-400' : 'text-rose-600 dark:text-rose-400') }}">
                            {{ ucfirst($comment->status) }}
                        </span>
                    </div>
                    <p class="text-xs text-zinc-600 dark:text-zinc-400">{{ $comment->content }}</p>
                </div>

                <div class="flex items-center gap-1.5 shrink-0 text-xs">
                    @if($comment->status !== 'approved')
                        <form method="POST" action="{{ route('admin.comments.status', $comment) }}">
                            @csrf @method('PATCH')
                            <input type="hidden" name="status" value="approved">
                            <button type="submit" class="inline-flex items-center justify-center h-8 w-8 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer transition" title="Approve Comment">
                                <i class="ri-check-line text-sm"></i>
                            </button>
                        </form>
                    @endif
                    @if($comment->status !== 'spam')
                        <form method="POST" action="{{ route('admin.comments.status', $comment) }}">
                            @csrf @method('PATCH')
                            <input type="hidden" name="status" value="spam">
                            <button type="submit" class="inline-flex items-center justify-center h-8 w-8 rounded-lg text-zinc-400 hover:text-amber-600 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer transition" title="Mark as Spam">
                                <i class="ri-spam-2-line text-sm"></i>
                            </button>
                        </form>
                    @endif
                    <form method="POST" action="{{ route('admin.comments.destroy', $comment) }}" onsubmit="return confirmDelete(event, 'Delete reader comment?')">
                        @csrf @method('DELETE')
                        <button type="submit" class="inline-flex items-center justify-center h-8 w-8 rounded-lg text-zinc-400 hover:text-rose-600 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer transition" title="Delete Comment">
                            <i class="ri-delete-bin-line text-sm"></i>
                        </button>
                    </form>
                </div>
            </div>
        @empty
            <p class="p-8 text-center text-xs text-zinc-400">No comments matching this filter.</p>
        @endforelse
    </div>
</div>
@endsection

