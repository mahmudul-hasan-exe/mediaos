@extends('layouts.admin')
@section('title', 'Categories')

@section('content')
<div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
    <div class="lg:col-span-8 space-y-4">
        <div>
            <h1 class="text-xl font-semibold text-zinc-900 dark:text-zinc-50 tracking-tight">Categories & Desks</h1>
            <p class="text-xs text-zinc-500 mt-0.5">Organize editorial sections and subcategories for {{ $tenant->name }}</p>
        </div>

        <div class="rounded-2xl border border-zinc-200/70 dark:border-zinc-800/80 bg-white dark:bg-zinc-900/50 divide-y divide-zinc-100 dark:divide-zinc-800/60">
            @forelse($categories as $cat)
                <div class="p-4 flex items-start justify-between gap-4">
                    <div>
                        <div class="flex items-center gap-2">
                            <h3 class="text-sm font-medium text-zinc-900 dark:text-zinc-100">{{ $cat->name }}</h3>
                            <span class="text-[11px] font-mono text-zinc-400">/{{ $cat->slug }}</span>
                            <span class="text-[11px] text-zinc-400">· {{ $cat->articles_count }} stories</span>
                        </div>
                        @if($cat->description)
                            <p class="text-xs text-zinc-500 mt-1">{{ $cat->description }}</p>
                        @endif
                        @if($cat->subcategories->isNotEmpty())
                            <div class="flex flex-wrap gap-1.5 mt-2">
                                @foreach($cat->subcategories as $sub)
                                    <span class="text-[11px] px-2 py-0.5 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300">
                                        {{ $sub->name }}
                                    </span>
                                @endforeach
                            </div>
                        @endif
                    </div>

                    <form method="POST" action="{{ route('admin.categories.destroy', $cat) }}" onsubmit="return confirmDelete(event, 'Delete category &quot;{{ addslashes($cat->name) }}&quot;?')">
                        @csrf @method('DELETE')
                        <button type="submit" class="text-xs text-zinc-400 hover:text-red-600 cursor-pointer">Delete</button>
                    </form>
                </div>
            @empty
                <p class="p-6 text-xs text-zinc-400 text-center">No categories found.</p>
            @endforelse
        </div>
    </div>

    <div class="lg:col-span-4">
        <form method="POST" action="{{ route('admin.categories.store') }}"
              class="rounded-2xl border border-zinc-200/70 dark:border-zinc-800/80 bg-white dark:bg-zinc-900/50 p-5 space-y-4">
            @csrf
            <h2 class="text-sm font-semibold text-zinc-900 dark:text-zinc-100">Add Category / Subcategory</h2>

            <div>
                <label class="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1">Name *</label>
                <input type="text" name="name" required class="w-full rounded-xl border border-zinc-200 dark:border-zinc-800 bg-transparent px-3 py-2 text-xs">
            </div>

            <div>
                <label class="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1">Parent Desk (Optional)</label>
                <select name="parent_id" class="w-full rounded-xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 px-3 py-2 text-xs">
                    <option value="">Top-Level Desk</option>
                    @foreach($categories as $cat)
                        <option value="{{ $cat->id }}">{{ $cat->name }}</option>
                    @endforeach
                </select>
            </div>

            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1">Accent Color</label>
                    <input type="color" name="color" value="#2563EB" class="h-9 w-full rounded-xl border border-zinc-200 dark:border-zinc-800 bg-transparent p-1">
                </div>
                <div>
                    <label class="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1">Order</label>
                    <input type="number" name="order" value="{{ $categories->count() + 1 }}" class="w-full rounded-xl border border-zinc-200 dark:border-zinc-800 bg-transparent px-3 py-2 text-xs">
                </div>
            </div>

            <div>
                <label class="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1">Description</label>
                <textarea name="description" rows="2" class="w-full rounded-xl border border-zinc-200 dark:border-zinc-800 bg-transparent px-3 py-2 text-xs"></textarea>
            </div>

            <button type="submit" class="w-full py-2 rounded-xl bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 text-xs font-medium cursor-pointer">
                Create Category
            </button>
        </form>
    </div>
</div>
@endsection

